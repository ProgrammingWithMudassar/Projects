import React from 'react'
import './App.css'
import Nabvar from './Components/Navbar.jsx'

function App() {

  return (
    <div className="App">
      <Nabvar />
    </div>
  )
}

export default App
