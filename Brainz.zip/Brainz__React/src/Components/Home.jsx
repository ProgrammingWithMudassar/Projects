import React from 'react'

const Home = () => {
  return (
    <>
      This is Header calling from ./Page/Home.jsx
    </>
  )
}

export default Home