import React from 'react'
import {
  Header
} from '../Components/index.js'

const Home = () => {
  return (
    <>
      <Header />
    </>
  )
}

export default Home