import Home from './Pages/Home/Home.jsx'

const App = () => {
  return (
    <>
      <Home />
    </>

  )
}

export default App
