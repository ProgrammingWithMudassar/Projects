import React from 'react';
import thumbs from '../../assets/img/thumbs/we_are_thum.png';
import yellowBigStar from '../../assets/img/icons/yellow_big_star.svg';
import yellowMediumStar from '../../assets/img/icons/yellow_medium_star.svg';
import greenStarBig from '../../assets/img/icons/green_star_big.svg';
import greenStarSmall from '../../assets/img/icons/green_star_small.svg';


const Home = () => {
    return (
        <div className="bg-[#080B2A]">
            {/*======== we are section Start =========*/}
            <section className="py-[20px] md:py-[95px] bg-[url('assets/img/bg/we_are_bg.png')] h-full w-full bg-cover">
                <div className="container">
                    <div className="grid grid-cols-12 gap-0 lg:gap-16">
                        <div className="mb-7 lg:mb-0 col-span-12 lg:col-span-5">
                            <img className="mx-auto lg:mx-0" src={thumbs} alt="" />
                        </div>
                        <div className="col-span-12 lg:col-span-7">
                            {/* --section-heading--  */}
                            <h2 className="text-left mb-[22px] text-[32px] md:text-[45px] text-[#fff] font-[600] font-clash">
                                Who we are ?
                            </h2>
                            <div className="">
                                <p className="text-left mb-4 text-[20px] md:text-[24px] text-[#ADAEB9] font-[400] font-satoshi tracking-[0.24px] leading-[34px]">
                                    The first meme coin to harness the power of Liquidity Staking Derivative Protocol.
                                </p>
                                <p className="text-left text-[20px] md:text-[24px] text-[#ADAEB9] font-[400] font-satoshi tracking-[0.24px] leading-[34px]">
                                    Our project merges the playful nature of meme coins with the intelligent strategies of smart investors,
                                    creating an innovative and rewarding experience. In this white paper, we will delve into the unique
                                    features of Brainz.Finance, including our lucrative rewards system, dynamic yield model, and automatic
                                    repeat feature.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </section>


            (
            <section className="mb-10 md:mb-0 pt-[80px] md:pt-[90px]">
                <div className="container">
                    <div className="flex flex-wrap gap-0 sm:gap-7 lg:gap-[40px] xl:gap-[60px] items-center">
                        {/* --power-left-- */}
                        <div className="order-2 lg:order-1 w-full lg:w-[55%]">
                            <div className="relative pt-5 pb-14">
                                {/* --star-- */}
                                <div className="hidden md:block">
                                    <img className="absolute right-[-10px] top-[40%]" src={yellowBigStar} alt="" />
                                    <img className="absolute left-[10%] top-[5%]" src={yellowMediumStar} alt="" />
                                    <img className="absolute left-[40%] top-0" src={yellowMediumStar} alt="" />
                                    <img className="absolute left-[35%] bottom-[5%]" src={yellowMediumStar} alt="" />
                                </div>
                                <h2 className="text-center md:text-left text-[32px] md:text-[35px] leading-[49px] md:leading-[60px] text-themeColor font-[600] font-clash">
                                    Unleash the Power of Your Investments with Brainz Finance - Transforming Ordinary into Extraordinary!
                                </h2>
                            </div>
                            <div className="w-full lg:max-w-[708px]">
                                <p className="mb-5 text-[21px] text-[#ADAEB9] font-[400] font-satoshi leading-[30px]">
                                    Our rewards system is designed to make your heart race with excitement. By staking your ETH or stETH,
                                </p>
                                <p className="text-center md:text-left mb-5 text-[21px] text-[#ADAEB9] font-[400] font-satoshi leading-[30px]">
                                    Our rewards system is designed to make your heart race with excitement. By staking your ETH or stETH, you
                                    stand a chance to earn a jaw-dropping APY ranging from 0% to a mind-boggling 2500%! Imagine the thrill of
                                    hitting the jackpot and seeing your assets multiply exponentially. But wait, there's more!
                                </p>
                                <p className="text-center md:text-left mb-5 text-[21px] text-[#ADAEB9] font-[400] font-satoshi leading-[30px]">
                                    We guarantee a solid 20% APY in $Brainz rewards, ensuring a steady stream of earnings.
                                </p>
                            </div>
                        </div>
                        {/* --power-right-- */}
                        <div className="order-1 lg:order-2 w-full lg:w-[40%] mb-6 lg:mb-0">
                            <div className="mx-auto lg:mx-0 relative flex justify-between h-[342px] w-[310px] sm:w-[480px]">
                                <div className="shrink-0 flex items-end">
                                    <div className="">
                                        <h6 className="text-[20px] sm:text-[26.933px] text-[#AB0202] font-[700] font-clash tracking-[0.26px]">
                                            0%
                                        </h6>
                                        <p className="text-[16px] sm:text-[21.546px] text-white font-[400] font-clash tracking-[0.215px]">
                                            jaw-dropping <br /> APY ranging from
                                        </p>
                                    </div>
                                </div>
                                <img
                                    className="absolute top-[30%] left-[12%] sm:left-[27%]"
                                    src="assets/img/icons/power_arrow.svg"
                                    alt=""
                                />
                                <div className="shrink-0 relative">
                                    {/* --stars-- */}
                                    <img className="absolute top-[-4%] right-0" src={greenStarBig} alt="" />
                                    <img className="absolute top-[-4%] left-[2%]" src={greenStarSmall} alt="" />
                                    <h6 className="text-[20px] sm:text-[26.933px] text-[#90FF9C] font-[700] font-clash tracking-[0.26px]">
                                        2500%!
                                    </h6>
                                    <p className="text-[16px] sm:text-[21.546px] text-white font-[400] font-clash tracking-[0.215px]">
                                        mind-boggling
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    );
};

export default Home;